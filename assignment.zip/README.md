# Project Name: Chase Your Brain

## _Features_

- In this project React Router used to navigate the link
- Tailwind CSS was used to apply the design and make it responsive
- Recharts used to show graphs on the static page
- A blog section was used to answer three question
- 404 component was added to show an error message

## Live site Link :

_Check here to visit :_ https://chase-your-brain.netlify.app/
